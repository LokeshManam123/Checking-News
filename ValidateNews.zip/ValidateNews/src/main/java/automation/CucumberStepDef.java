package automation;

import automation.common.ScreenShotMaker;
import automation.config.Browser;
import automation.google.pages.GoogleSearchPage;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//import org.junit.Assert;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CucumberStepDef {
    protected WebDriver driver;
    private Browser google = new Browser(driver);
    GoogleSearchPage googleSearchPage;
    List<String> theGuardianResult = new ArrayList<>();
    List<String> theGoogleResult = new ArrayList<>();
    String searchiValues;
    ArrayList finaliList = new ArrayList();

    @Before
    public void setUp() {
        driver = google.getBrowser();
        google.openURL();
        }



    @Given("^User Logged into news portal article$")
    public void user_Logged_into_news_portal_article() throws Throwable {
        google.openURL();
    }

    @Given("^Copy the news article$")
    public void copy_the_news_article() throws Throwable {
        googleSearchPage = PageFactory.initElements(driver,GoogleSearchPage.class);
        theGuardianResult= googleSearchPage.readSearchResultsGuardian();

    }

    @When("^Verify news article with other news portals$")
    public void verify_news_article_with_other_news_portals() throws Throwable {
        google.openNewTab();
        searchiValues=theGuardianResult.get(1);
        googleSearchPage.searchText(searchiValues);
        theGoogleResult=googleSearchPage.readSearchResultsGoogle();

    }

    @When("^News article matches$")
    public void news_article_matches() throws Throwable {

        for(String splitResult : theGoogleResult){
            String[] splitValue =splitResult.split(" ");
            List<String> storteString = new ArrayList<>();
            storteString = Arrays.asList(splitValue);
            int count=0;
            int notCounted =0;
            for(String counting : storteString){
                if(searchiValues.contains(counting)){
                    count++;
                }else{
                    notCounted++;
                }
            }
            if(count>notCounted){
                finaliList.add(splitResult);

            }

        }



    }

    @Then("^News is valid \"([^\"]*)\"$")
    public void news_is_valid(String arg1) throws Throwable {
        if(finaliList.size()>=1){
            Assert.assertEquals("true",arg1);
        }
        else{
            Assert.assertEquals("false",arg1);
            ScreenShotMaker.getInstance().takeScreenShot(driver,
                    this.getClass().getCanonicalName());
        }

    }
    @Then("^News is invalid \"([^\"]*)\"$")
    public void news_is_invalid (String arg1) throws Throwable {
        if(finaliList.size()>=1){
            Assert.assertEquals("true",arg1);
        }
        else{
            Assert.assertEquals("false",arg1);
            ScreenShotMaker.getInstance().takeScreenShot(driver,
                    this.getClass().getCanonicalName());
        }

    }

}
