/**
 * @author jagdeepjain
 *
 */
package automation.google.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GoogleSearchPage {
    // locators
    @FindBy(xpath ="//input[@type='text']")
    private WebElement searchInputBox;
    @FindBy(name = "btnG")
    private WebElement searchButton;
    @FindBy(id = "top")
    private WebElement searchResultGardian;
    @FindBy(id = "gsr")
    private WebElement searchResultGoogle;
    By searchResultHeader = By.tagName("h3");
    By searchResultHeadergoogle = By.tagName("a");
    
    // perform search action with the given text
    public void searchText(String text) {
        searchInputBox.sendKeys(text);
       // searchButton.click();
        searchInputBox.sendKeys(Keys.ENTER);
    }
    
    public List<String> readSearchResultsGuardian() throws InterruptedException {
        List<WebElement> searchResults = searchResultGardian
                .findElements(searchResultHeader);
        Thread.sleep(10000);
        
        List<String> searchResultsHeaderText = new ArrayList<String>();
        int size = searchResults.size();
        for (int i = 0; i < size; i++) {
            searchResultsHeaderText.add(searchResults.get(i).getText());
         System.out.println("the guridan"+searchResults.get(i).getText());
        }
        return searchResultsHeaderText;
    }

    public List<String> readSearchResultsGoogle() throws InterruptedException {
        List<WebElement> searchResults = searchResultGoogle
                .findElements(searchResultHeadergoogle);
        List<WebElement> searchResultsLink = searchResultGoogle
                .findElements(searchResultHeader);
        Thread.sleep(10000);

        List<String> searchResultsHeaderText = new ArrayList<String>();
        int size = searchResults.size();
        for (int i = 0; i < size; i++) {
            if(!searchResults.get(i).getText().equalsIgnoreCase("")) {
                if(searchResults.get(i).getText().contains(".com")&&!searchResults.get(i).getText().contains("theguardian")) {
                    searchResultsHeaderText.add(searchResults.get(i).getText());
                    System.out.println("Google="+searchResults.get(i).getText());
                }
            }

        }

        ArrayList finalresult = new ArrayList();
        for(int i=0;i<searchResultsLink.size();i++){
            System.out.println("tage"+searchResultsLink.get(i).getText());
            for(int j=0;j<searchResultsHeaderText.size();j++){
                if(searchResultsHeaderText.get(j).contains(searchResultsLink.get(i).getText())){
                   if(!finalresult.contains(searchResultsHeaderText.get(j))){
                       finalresult.add(searchResultsLink.get(i).getText());
                       System.out.println("final="+searchResultsLink.get(i).getText());
                   }
                }
            }
        }
        return finalresult;
    }
}
