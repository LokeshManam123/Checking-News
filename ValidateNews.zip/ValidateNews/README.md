we have implemented method in build.gradle tag based selenium execution 

Purpose of Implenetation:
Here we can execute particular test case passing tags as parameter so it wil lexecute particular tag based 
all over the project.

below are the run command in gradle terminal:
gradle runWinTags